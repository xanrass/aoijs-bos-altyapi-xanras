module.exports ={
  name: "ping",
  code: `🏓 Anlık gecikmemi **$pingms** olarak hesapladım.`
}