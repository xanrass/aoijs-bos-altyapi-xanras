module.exports =[{
  name: "<@$clientID>",
  nonPrefixed: true,
  code: `Merhaba, bu sunucuda **$getServerVar[prefix]** sembolü prefiximdir.`
}, {
  name: "<@!$clientID>",
  nonPrefixed: true,
  code: `Merhaba, bu sunucuda **$getServerVar[prefix]** sembolü prefiximdir.`
}] 
